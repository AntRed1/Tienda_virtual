export const environment = {
  production: true,
  emailJsServiceId: 'service_51ybpem',
  emailJsTemplateId: 'template_1njpz8d',
  emailJsPublicKey: 'hUpnRA1Hvf0HEwzZ_',
};
