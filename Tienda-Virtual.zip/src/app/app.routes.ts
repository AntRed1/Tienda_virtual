import { Routes } from '@angular/router';
import { MainComponent } from './component/main/main.component';
import { LoginComponent } from './component/pages/login/login.component';
import { ContactsComponent } from './component/pages/contacts/contacts.component';

export const routes: Routes = [
  {
    path: 'dashboard',
    component: MainComponent,
  },
  {
    path: 'login',
    component: LoginComponent,
  },
  {
    path: 'contacts',
    component: ContactsComponent,
  },
];
