import { ContactsComponent } from './../pages/contacts/contacts.component';
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { FooterComponent } from '../footer/footer.component';
import { LoginComponent } from '../pages/login/login.component';
import { AuthService } from '../../services/auth.service';
import { ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [FooterComponent, CommonModule, LoginComponent, ContactsComponent, ReactiveFormsModule],
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css'],
})
export class HeaderComponent implements OnInit {
  title = 'Tienda Virtual';
  isLoggedIn = false;
  name = '';

  constructor(private authService: AuthService, private router: Router) {}

  ngOnInit() {
    this.isLoggedIn = this.authService.isLoggedIn();
  }

  login() {
    if (this.isLoggedIn) {
      alert('Ya has iniciado sesión');
    } else {
      this.router.navigate(['/login']);
    }
  }

  logout() {
    this.authService.logout();
    this.isLoggedIn = false;
  }

  navigateToContacts() {
    this.router.navigate(['/contacts']); // Navega hacia la ruta de 'contacts'
  }

  navigateToDashboard() {
    this.router.navigate(['/dashboard']); // Navega hacia la ruta de 'Home
  }
}
