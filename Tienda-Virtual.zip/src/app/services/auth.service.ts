import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private userKey = 'user';

  constructor() {}

  isLoggedIn(): boolean {
    const user = localStorage.getItem(this.userKey);
    return user !== null;
  }

  login(email: string, password: string): boolean {
    const user = JSON.parse(localStorage.getItem(this.userKey) || '{}');
    if (user.email === email && user.password === password) {
      localStorage.setItem('isLoggedIn', 'true');
      return true;
    }
    return false;
  }

  register(user: any): void {
    localStorage.setItem(this.userKey, JSON.stringify(user));
  }

  logout(): void {
    localStorage.removeItem('isLoggedIn');
    localStorage.removeItem(this.userKey);
  }

  getUser(): any {
    return JSON.parse(localStorage.getItem(this.userKey) || '{}');
  }
}
